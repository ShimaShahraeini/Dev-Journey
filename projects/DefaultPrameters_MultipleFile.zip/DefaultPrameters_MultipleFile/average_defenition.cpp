#include <iostream>
#include "average_header.h"

float average(int a, int b, int c){
    float sum = a + b + c;
    return sum / 3.0f;
}