/* Cpp programming
dev journey: 
in this code first we practiced that if you call a funtion and pass the arguments to it you can only 
use the defult argument for the lasts argument
we also used extern to share functions across multiple C++ files
*/

#include <iostream>
#include "average_header.h"

int main() {
    float result1 = average(10, 5, 2); // Explicit arguments
    std::cout << "Average (10, 5, 2): " << result1 << std::endl;

    float result2 = average(); // Uses default arguments
    std::cout << "Average (default): " << result2 << std::endl;

    float result3 = average(8); // Uses default arguments
    std::cout << "Average (default): " << result3 << std::endl;

    /*ERROR!
    float result4 = average(, ,2); // Uses default arguments
    std::cout << "Average (default): " << result4 << std::endl;*/

    return 0;
}