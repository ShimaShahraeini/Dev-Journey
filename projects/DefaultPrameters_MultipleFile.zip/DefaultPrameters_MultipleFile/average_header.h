#ifndef AVARAGE_HEADER_H
#define AVARAGE_HEADER_H

extern float average(int a=12, int b=4, int c=3);

#endif