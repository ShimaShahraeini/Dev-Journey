/* C++ programming
dev journey: Using extern to share functions across multiple C++ files involves these key steps:
1.Create a Header File 

    This header file will contain the declaration of your function.
    It's crucial that all files that use the function include this header.

    keep that in mind Default arguments must be known at compiletime 
    since at that moment arguments are supplied to functions.
    Therefore, the default arguments must be mentioned at the function's declaration, rather than at its implementation

2.Create a Source File 

    This file will contain the definition (implementation) of your function.

3. Create Another Source File 

    This file will use the function declared in my_functions.h.
    Include the header file.
*/