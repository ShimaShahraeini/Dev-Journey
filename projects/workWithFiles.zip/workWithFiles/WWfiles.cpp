/*Cpp programming
dev journey:
in this code i practiced working with files input/output how to open close add or get from it and i also worked with flags of it
then i got curious of what happens if i add data not just at the end of file(appending). 
feel free to comment out 2 and 3 and run them step by step to see the result 
at 4th part for practicing how to work with pointers on file and where it is i made simple useage of geting the size of the file!!
*/
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <filesystem>
using namespace std;

string filename = "data.txt";

void addline(const string& newLine) {
    fstream file(filename , ios::in | ios::out );// without using ios::trunc flag

    if (!file) {
        cerr << "Error: Could not open file " << filename << " for writeing in addline" << endl;
        cout << "Current working directory: " << std::filesystem::current_path() << endl;
        return;
    }

    file << newLine << endl;
    file.close();
    return;
}

void insertline(const string& newLine,int where) {
    //put 'newLine' in 'where' possition
    string tempFilename = "temp.txt";
    ifstream inFile(filename);
    ofstream outFile(tempFilename);

    if (!inFile.is_open()) {
        cerr << "Error: Could not open file " << filename << " for reading in insertline" << endl;
        cout << "Current working directory: " << std::filesystem::current_path() << endl;
        return;
    }

    if (!outFile.is_open()) {
        cerr << "Error: Could not open temp.txt for writing in insertline." << endl;
        inFile.close();
        return;
    }

    string line;
    int lineCount = 0;
    bool inserted = false;

    while (getline(inFile, line)) {
        outFile << line << endl;
        lineCount++;
        if (lineCount == where && !inserted) {
            outFile << newLine << endl;
            inserted = true;
        }
    }

    if (!inserted) { // Handle the case where the file has 0 or 1 lines
        outFile << newLine << endl;
    }

    inFile.close();
    outFile.close();

    // Replace the original file with the temporary file
    if (filesystem::remove(filename)) { //if the original file is removed successfully.
        filesystem::rename(tempFilename, filename);
    } else {
        cerr << "Error: could not remove original file\n";
    }
}

long getFileSize(const string& filename) {
    ifstream file(filename, ios::binary | ios::ate); // Open in binary and go to end

    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << " for reading." << endl;
        cout << "Current working directory: " << std::filesystem::current_path() << endl;
        return -1; // Indicate an error
    }

    long size = file.tellg(); // Get current position (end of file)
    file.close();

    return size;
}

int main() {
    //1.

    // We'll make a file called data.txt
    fstream file(filename, ios::in | ios::out | ios:: trunc);


    if (!file) { // Correctly check if the stream is open
        cerr << "Error: Could not open file " << filename << " for writing/reading." << endl;
        cout << "Current working directory: " << std::filesystem::current_path() << endl;
        return 1; // Indicate an error
    }

    //We'll write two lines into this file 
    file << "Hello world!" << endl;

    string line;
    while (getline(file, line)) { // Read lines until end of file
        std::cout << line << std::endl;        // Print each line to console
    }
    file.close(); //close the file.


    //2.
    //this is to test if this string would overwrite or append to begining of a file
    addline("This is line 1\nTHis is line 3"); //by running this function i learnd it overwites the data

    //3.
    //what if i want to actully append data somewhere in file and keep the currunt data?(be aware )
    insertline("THis is line 2", 1);

    //4. how can i have size of the file?
    long size = getFileSize(filename);
    if (size != -1) {
        cout << "Size of "<<filename<<": " << size << " bytes." << endl;
    }

    return 0; // Indicate successful execution
}
