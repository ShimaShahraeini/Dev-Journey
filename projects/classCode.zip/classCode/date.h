//date.h

#ifndef Date_H
#define Date_H

class Date{
private:
    int m_nMonth;
    int m_nDay;
    int m_nYear;
    static int objectCount; // Static member variable declaration (count objects)
    Date();//this line make the defualt constructor privet so when the object get created it has to be in specific form that we force it!
public:
    Date(int nMonth, int nDay, int nYear);
    void SetDate(int nMonth, int nDay, int nYear);
    int getMonth() const;
    int getDay() const;
    int getYear() const;   
    static int getObjectCount(); 
};
#endif