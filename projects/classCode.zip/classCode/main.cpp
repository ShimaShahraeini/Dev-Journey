/*Cpp programming
dev journey: 
1. by this code we practiced making classes while implement it as a header file!
2. we also practiced const obj in here we know When you declare an object as const,
you're telling the compiler that the object's state should not be modified after it's initialized.
This means you cannot call any member functions that might change the object's member variables.
but i also learned:
    Getter functions (like getMonth(), getDay(), and getYear()) are typically designed to read the object's state without modifying it.
    Therefore, they should be declared as const member functions.
    If those functions are declared as const, a const object can call them.(check out header file)
    if you don't add and say the getter functions are const it gets an error
3. another thing that we practiced was static member variable we know it is associated with the class, not with individual instances (objects) of the class.
There's only one copy of a static member variable, regardless of how many objects of the class are created.t
*/

#include <iostream>
#include "date.h"

int main() {
    std::cout << "Initial object count: " << Date::getObjectCount() << std::endl;

    Date myDate(12, 25, 2023); // Create a Date object

    std::cout << "Month: " << myDate.getMonth() << std::endl;
    std::cout << "Day: " << myDate.getDay() << std::endl;
    std::cout << "Year: " << myDate.getYear() << std::endl;
    std::cout << "Object count after myDate: " << Date::getObjectCount() << std::endl;


    myDate.SetDate(1, 1, 2024); // Change the date

    std::cout << std::endl << "New Month: " << myDate.getMonth() << std::endl;
    std::cout << "New Day: " << myDate.getDay() << std::endl;
    std::cout << "New Year: " << myDate.getYear() << std::endl;


    const Date thatdate(7, 7, 2003);
    std::cout << std::endl << thatdate.getMonth() << "/ " << thatdate.getDay() << "/ " << thatdate.getYear()<< std::endl;
    //thatdate.SetDate(1, 1, 2024); this will cuase an error! you cant change thevalues in this obj you declared it as const.
    std::cout << "Object count after thatDate: " << Date::getObjectCount() << std::endl;

    {
        Date anotherDate(1, 1, 2024);
        std::cout << "Object count inside scope: " << Date::getObjectCount() << std::endl;
    }

    std::cout << "Object count after scope: " << Date::getObjectCount() << std::endl;



    return 0;
}