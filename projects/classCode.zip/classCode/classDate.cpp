//classDate.cpp
#include "date.h"

//creat constructor
Date::Date(){}
#include "date.h"

// Definition and initialization of the static member variable
int Date::objectCount = 0;

// Constructor implementation
Date::Date(int nMonth, int nDay, int nYear) {
    SetDate(nMonth, nDay, nYear);
    objectCount++; // Increment the count when an object is created
}

// SetDate implementation
void Date::SetDate(int nMonth, int nDay, int nYear) {
    m_nMonth = nMonth;
    m_nDay = nDay;
    m_nYear = nYear;
}

// GetMonth implementation
int Date::getMonth() const {
    return m_nMonth;
}

// GetDay implementation
int Date::getDay() const {
    return m_nDay;
}

// GetYear implementation
int Date::getYear() const {
    return m_nYear;
}

// Static member function to get object count
int Date::getObjectCount() {
    return objectCount;
}